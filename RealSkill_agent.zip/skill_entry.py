# skill_entry.py
# RealSkill - Agent 本地调用入口

import os
import sys
from dotenv import load_dotenv

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
load_dotenv()

from core.generator import generate_variants
from core.judge import judge_and_select, detect_ai_score
from core.humanize import humanize_by_llm, rule_based_humanize

def generate(topic: str, platform: str, style_refs: list = None) -> dict:
    if style_refs is None:
        style_refs = []

    variants = generate_variants(topic, platform)
    verdict = judge_and_select(variants, platform)
    winner_key = verdict.get("winner", "B")
    best_text = variants[winner_key]

    humanized = humanize_by_llm(best_text)
    final = rule_based_humanize(humanized, platform)

    final_ai_score = detect_ai_score(final)
    if final_ai_score > 7:
        risk = "low"
    elif final_ai_score > 4:
        risk = "medium"
    else:
        risk = "high"

    return {
        "result": final,
        "winner_agent": winner_key,
        "all_variants": variants,
        "scores": verdict.get("scores", {}),
        "ai_detection_risk": risk,
        "ai_score": round(final_ai_score, 1),
        "platform": platform,
    }
